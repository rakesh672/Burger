import React from 'react';
import classNamees from './CardDetail.css';
import Toolbar from '../../Navigation/Toolbar/Toolbar';
import acceptedCards from '../../../assets/Images/acceptedCards.png';
import img1 from '../../../assets/Images/img1.png';
import img2 from '../../../assets/Images/img2.png';
import img3 from '../../../assets/Images/img3.png';



const cardStyle={marginTop: "10%",
    boxShadow: "5px 10px #888888",
    border: "2px solid #000000",
    width:"50%",
    margin:"10% auto"};

const cardDetail = () => {
    return (
        <div>
            <Toolbar />
            <article className="card" style={cardStyle}>
                <div className="card-body p-5">
                    <p> <img src={img1} />
                        <img src={img2} />
                        <img src={img3} />
                    </p>
                    <form role="form">
                        <div className="form-group">
                            <label for="username">Full name (on the card)</label>
                            <div className="input-group">
                                <div className="input-group-prepend">
                                    <span className="input-group-text"><i className="fa fa-user"></i></span>
                                </div>
                                <input type="text" className="form-control" name="username" placeholder="" required="" />
                            </div>
                        </div>

                        <div className="form-group">
                            <label for="cardNumber">Card number</label>
                            <div className="input-group">
                                <div className="input-group-prepend">
                                    <span className="input-group-text"><i className="fa fa-credit-card"></i></span>
                                </div>
                                <input type="text" className="form-control" name="cardNumber" placeholder="" />
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-sm-8">
                                <div className="form-group">
                                    <label><span className="hidden-xs">Expiration</span> </label>
                                    <div className="form-inline">
                                        <select className="form-control" style={{width:"45%"}}>
                                            <option>MM</option>
                                            <option>01 - Janiary</option>
                                            <option>02 - February</option>
                                            <option>03 - February</option>
                                        </select>
                                        <span style={{width:"10%", textAlign: "center"}}> / </span>
                                        <select className="form-control" style={{width:"45%"}}>
                                            <option>YY</option>
                                            <option>2018</option>
                                            <option>2019</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div className="col-sm-4">
                                <div className="form-group">
                                    <label data-toggle="tooltip" title="" data-original-title="3 digits code on back side of the card">CVV <i className="fa fa-question-circle"></i></label>
                                    <input className="form-control" required="" type="text" />
                                </div>
                            </div>
                        </div>
                        <button className="subscribe btn btn-primary btn-block" type="button"> Confirm  </button>
                    </form>
                </div>
            </article>
        </div>
    );
}
export default cardDetail;