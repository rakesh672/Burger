import React, { Component } from 'react';
import classes from './BillingAddress.css';
import Toolbar from '../../Navigation/Toolbar/Toolbar';

class BillingAddress extends Component {
    submitHandler = () => {
        this.props.history.push("/CardDetail");
    }

    render() {
        return (
            <div>
                <Toolbar />
                <div className={classes.container}>
                    <div className={classes.accordion}>
                        <div className="container-fluid" style={{paddingTop: "20px",margin:"7% auto"}}>
                            <p className={classes.headings}>Shipping Address</p>
                            <form className="main-container">
                                <div className="row">
                                    <div className="col-xs-4">
                                        <label htmlFor="fullname" className={classes["label-style"]}>Full Name</label>
                                    </div>
                                    <div className="form-group col-lg-4">
                                        <input type="text" id="fullname" className="form-control" placeholder="Enter your full name" required />
                                    </div>
                                    <div className={classes.hint}>
                                        <i className={classes["hint-icon"]}>i</i>
                                        <p className={classes["hint-description"]}>Enter your full name</p>
                                    </div>
                                </div>


                                <div className="row">
                                    <div className="col-xs-4">
                                        <label htmlFor="companyname" className={classes["label-style"]}>Company Name</label>
                                    </div>
                                    <div className="form-group col-lg-4">
                                        <input type="text" id="companyname" className="form-control" placeholder="Enter Company Name (optional)" required />
                                    </div>
                                    <div className={classes.hint}>
                                        <i className={classes["hint-icon"]}>i</i>
                                        <p className={classes["hint-description"]}>Enter your Company name</p>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-xs-4">
                                        <label htmlFor="phonenumber" className={classes["label-style"]}>Phone Number</label>
                                    </div>
                                    <div className="form-group col-lg-4">
                                        <input type="text" id="phonenumber" className="form-control" placeholder="Enter Phone Number" required />
                                    </div>
                                    <div className={classes.hint}>
                                        <i className={classes["hint-icon"]}>i</i>
                                        <p className={classes["hint-description"]}>In (555)5555-555 Format</p>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-xs-4">
                                        <label htmlFor="address-line1" className={classes["label-style"]}>Address Line 1</label>
                                    </div>
                                    <div className="form-group col-lg-4">
                                        <input type="text" id="address-line1" className="form-control" placeholder="Enter Address" required />
                                    </div>
                                    <div className={classes.hint}>
                                        <i className={classes["hint-icon"]}>i</i>
                                        <p className={classes["hint-description"]}>Address Line 1</p>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-xs-4">
                                        <label htmlFor="address-line2" className={classes["label-style"]}>Line 2</label>
                                    </div>
                                    <div className="form-group col-lg-4">
                                        <input type="text" id="address-line2" className="form-control" placeholder="Apt, Suite, Bldg (optional)" required />
                                    </div>
                                    <div className={classes.hint}>
                                        <i className={classes["hint-icon"]}>i</i>
                                        <p className={classes["hint-description"]}>Address Line 2</p>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-xs-4">
                                        <label htmlFor="city" className={classes["label-style"]}>City</label>
                                    </div>
                                    <div className="form-group col-lg-4">
                                        <input type="text" id="city" className="form-control" placeholder="Enter City" required />
                                    </div>
                                    <div className={classes.hint}>
                                        <i className={classes["hint-icon"]}>i</i>
                                        <p className={classes["hint-description"]}>Enter your City</p>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-xs-4">
                                        <label htmlFor="state" className={classes["label-style"]}>State</label>
                                    </div>
                                    <div className="form-group col-lg-4">
                                        <input type="text" id="state" className="form-control" placeholder="Enter State" required />
                                    </div>
                                    <div className={classes.hint}>
                                        <i className={classes["hint-icon"]}>i</i>
                                        <p className={classes["hint-description"]}>Ex: Indiana as IN</p>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-xs-4">
                                        <label htmlFor="country" className={classes["label-style"]}>Country</label>
                                    </div>
                                    <div className="form-group col-lg-4">
                                        <input type="text" id="country" className="form-control" placeholder="Enter Country" required />
                                    </div>
                                    <div className={classes.hint}>
                                        <i className={classes["hint-icon"]}>i</i>
                                        <p className={classes["hint-description"]}>Enter your country</p>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-xs-4">
                                        <label htmlFor="zipcode" className={classes["label-style"]}>Zip Code</label>
                                    </div>
                                    <div className="form-group col-lg-4">
                                        <input type="text" id="zipcode" className="form-control" placeholder="Enter Zip Code" required />
                                    </div>
                                    <div className={classes.hint}>
                                        <i className={classes["hint-icon"]}>i</i>
                                        <p className={classes["hint-description"]}>Enter ZipCode.</p>
                                    </div>
                                </div>
                                <div className={classes["button-container"]}>
                                    <button className="btn btn-success" type="submit" onClick={this.submitHandler}>Submit</button>
                                    <button className="btn btn-warning" type="reset">Reset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

}

export default BillingAddress;