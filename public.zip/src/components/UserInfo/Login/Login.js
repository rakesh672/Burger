import React, { Component } from 'react';
import classes from './Login.css';
import { Redirect, Link } from "react-router-dom";
import Toolbar from '../Navigation/Toolbar/Toolbar';

class Login extends Component {
    loginClickHandler = () => {
        this.props.history.push("/App");
        console.log(this);
    }

    render() {
        return (
            <div>
                <Toolbar/>
                <div className={classes.login}>
                    <div className="containerlimit">
                        <div className="d-flex align-items-center logindivheight">
                            <div className="shadow p-4 bg-white rounded loginwidth" style={{ margin: "auto", marginTop: "100px" }}>
                                <form>
                                    <h1 className="display-3 py-3">Login</h1>
                                    <div className="input-group mb-3">
                                        <div className="input-group-prepend">
                                            <span className="input-group-text" >
                                                <i className="fas fa-envelope"></i>
                                            </span>
                                        </div>
                                        <input type="text" className="form-control input100"
                                            placeholder="Email" id="email" aria-label="Email"
                                            aria-describedby="email" required />
                                    </div>
                                    <div className="input-group mb-3">
                                        <div className="input-group-prepend">
                                            <span className="input-group-text" >
                                                <i className="fas fa-lock"></i>
                                            </span>
                                        </div>
                                        <input type="password" className="form-control input100"
                                            placeholder="Password" id="password" aria-label="Password"
                                            aria-describedby="password" required />
                                    </div>
                                    <div className="form-check">
                                        <input type="checkbox" className="form-check-input" id="rememberme" />
                                        <label className="form-check-label" htmlFor="rememberme">Remember me</label>
                                    </div>
                                    <div className="container-form-btn p-t-25 py-3">
                                        <button className="btn btn-primary btn-lg btn-block" onClick={this.loginClickHandler}>
                                            Login
								</button>
                                    </div>
                                </form>
                                <p className="p-2">
                                    Or login with
						</p>
                                <div className="d-flex justify-content-center">
                                    <a href="#" className="btn-face m-b-10">
                                        <i className="fab fa-facebook"></i>
                                        &nbsp;Facebook
							</a>

                                    <a href="#" className="btn-google m-b-10">
                                        <i className="fab fa-google"></i>
                                        &nbsp;Google
							</a>
                                </div>

                                <p className="lead py-4">
                                    Not a memeber yet? <Link to="/register">Sign Up</Link>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Login;