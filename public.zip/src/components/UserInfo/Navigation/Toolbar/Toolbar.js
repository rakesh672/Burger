import React from 'react';
import classes from './Toolbar.css';
import LogoImage from '../../../../assets/Images/burgerFlame.jpg';
import Logo from '../../../Logo/Logo';

const toolbar=()=>{
return(
    <header className={classes.Toolbar}>
        <Logo logo={LogoImage} />
        <div className="text-center w-100">
        <h1>Hot Burger..</h1>
        </div>
    </header>
);
}

export default toolbar;