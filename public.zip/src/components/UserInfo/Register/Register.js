import React, { Component } from 'react';
import classes from './Register.css';
import { Redirect, Link } from "react-router-dom";
import Toolbar from '../Navigation/Toolbar/Toolbar';

class Register extends Component {
    render() {
        return (
            <div>
                <Toolbar />
                <div className={classes.register}>
                    <div className="containerlimit">
                        <div className="d-flex align-items-center logindivheight">
                            <div className="shadow p-4 bg-white rounded loginwidth" style={{ margin: "auto", marginTop: "100px" }}>
                                <form>
                                    <h1 className="display-3 py-3">Register</h1>
                                    <div className="form-group">
                                        <label for="firstname">First Name</label>
                                        <input type="text" className="form-control" id="firstname"
                                            placeholder="First Name" required />
                                    </div>
                                    <div className="form-group">
                                        <label for="lastname">Last Name</label>
                                        <input type="text" className="form-control" id="lastname"
                                            placeholder="Last Name" required />
                                    </div>
                                    <div className="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" className="form-control" id="email"
                                            placeholder="Email" />
                                    </div>
                                    <div className="form-group">
                                        <label for="lastname">Phone</label>
                                        <input type="text" className="form-control" id="phone"
                                            placeholder="Phone" required />
                                    </div>
                                    <div className="form-group">
                                        <label for="lastname">Zip</label>
                                        <input type="text" className="form-control" id="zip"
                                            placeholder="Phone" required />
                                    </div>
                                    <div className="container-form-btn p-t-25 py-3">
                                        <button className="btn btn-primary btn-lg btn-block">
                                            Register
								</button>
                                    </div>
                                </form>
                                <p className="lead py-4">
                                    Already a member? <Link to="/">Login</Link>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Register;