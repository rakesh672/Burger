import React from 'react';
import classes from '../../UI/Modal/Modal.css';
import Backdrop from '../../UI/Backdrop/Backdrop';

const popupModel = (props) => {
    return (
        props.text.length > 0 ? <div>
            <Backdrop show={props.text.length > 0} />
            <div className={classes.Modal} style={
                {
                    transform: props.text.length > 0 ? 'translateY(0)' : 'translateY(-100vh)',
                    opacity: props.text.length > 0 ? 1 : 0,
                    textAlign: "center",
                    width:"300px"
                }
            }>
                <div>
                    <p>{props.text}</p>
                    <button onClick={props.closePopup}>Close</button>
                </div>
            </div>
        </div> : null
    );
}

export default popupModel;