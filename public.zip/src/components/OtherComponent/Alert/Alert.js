import React from 'react';

import {Button} from 'reactstrap';

const alert = (props)=>{
    return(
        <div>
        <Button color="primary">{props.text}</Button>{' '}
        </div>
    );
}

export default alert;