import React, { Component } from 'react';
import Button from '../../UI/Button/Button';

class OrderSummery extends Component {
    render() {
        const ingredientSummery = Object.keys(this.props.ingredients)
            .map(igKey => {
                return <li key={igKey}>
                    <span style={{ textTransform: 'capitalize' }}>{igKey}</span>:{this.props.ingredients[igKey]}
                </li>
            });
        return (
            <div>
                <h3>Your order</h3>
                <p>Delicious burger with following ingredients:</p>
                <ul>
                    {ingredientSummery}
                </ul>
                <p><strong>Total price:{this.props.totalPrice.toFixed(2) + "$"}</strong></p>
                <p>Continue to checkout.</p>
                <Button btnType="Danger" clicked={this.props.conform}>Cancel</Button>
                <Button btnType="Success" clicked={this.props.continue}>Continue</Button>
            </div>
        )
    }
}

export default OrderSummery;