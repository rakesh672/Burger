import React from 'react';
import NavigationItem from './NavigationItem/NavigationItem';
import classes from './NavigationItems.css';
import { Redirect, Link } from "react-router-dom";


const navigationItems=()=>{
    return(
            <ul className={classes.NavigationItems}>
                <NavigationItem> <Link to="/App">Burger Builder</Link></NavigationItem>
                <NavigationItem><Link to="/">Logout</Link></NavigationItem>
            </ul>
    );
}

export default navigationItems;