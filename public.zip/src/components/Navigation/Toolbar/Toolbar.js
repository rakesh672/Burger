import React from 'react';
import classes from './Toolbar.css';
import LogoImage from '../../../assets/Images/burger-logo.png';
import Logo from '../../Logo/Logo';
import NavigationItems from '../NavigationItems/NavigationItems';

const toolbar=()=>{
return(
    <header className={classes.Toolbar}>
        <div>MENU</div>
        <Logo logo={LogoImage} />
        <nav>
           <NavigationItems />
        </nav>
    </header>
);
}

export default toolbar;