import React,{Component} from 'react';
import App from './App';
import Login from '../src/components/UserInfo/Login/Login';
import Register from '../src/components/UserInfo/Register/Register';
import CardDetail from '../src/components/Billing/CardDetail/CardDetail';
import BurgerBuilder from '../src/containers/BurgerBuilder/BurgerBuilder';
import BillingAddress from '../src/components/Billing/BillingAddress/BillingAddress';

import {BrowserRouter,Switch,Route,Link} from "react-router-dom";

class Main extends Component{
    render(){
        return(
            <BrowserRouter>
                <Switch>
                    <Route exact path="/" component={Login}/>
                    <Route path="/App" component={App}/>
                    <Route path="/Register" component={Register}/>
                    <Route path="/CardDetail" component={CardDetail} />
                    <Route path="/BurgerBuilder" component={BurgerBuilder} />
                    <Route path="/BillingAddress" component={BillingAddress} />
                </Switch>
            </BrowserRouter>
            );
    }
} 

export default Main;